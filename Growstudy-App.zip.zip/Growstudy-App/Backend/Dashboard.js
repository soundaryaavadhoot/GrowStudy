import React, { useEffect, useState } from "react";
import axios from "axios";

const TaskDashboard = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");
  const [category, setCategory] = useState("daily");

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const res = await axios.get("http://localhost:5000/tasks");
    setTasks(res.data);
  };

  const addTask = async () => {
    if (!newTask) return alert("Enter a task!");
    await axios.post("http://localhost:5000/tasks", { 
      title: newTask, category, dueDate: new Date() 
    });
    fetchTasks();
    setNewTask("");
  };

  const toggleStatus = async (id, status) => {
    await axios.put(`http://localhost:5000/tasks/${id}`, { 
      status: status === "Incomplete" ? "Complete" : "Incomplete" 
    });
    fetchTasks();
  };

  return (
    <div className="p-5 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Task Dashboard</h1>

      {/* Task Input */}
      <div className="mb-4 flex gap-2">
        <input
          type="text"
          className="border p-2 flex-grow"
          placeholder="New task..."
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <select
          className="border p-2"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
        <button className="bg-blue-500 text-white p-2" onClick={addTask}>
          Add Task
        </button>
      </div>

      {/* Task List */}
      {["daily", "weekly", "monthly"].map((cat) => (
        <div key={cat} className="mb-5">
          <h2 className="text-lg font-bold capitalize">{cat} Tasks</h2>
          <ul>
            {tasks
              .filter((task) => task.category === cat)
              .map((task) => (
                <li key={task._id} className="flex justify-between p-2 border-b">
                  <span>{task.title}</span>
                  <button
                    className={`p-1 px-3 ${
                      task.status === "Complete"
                        ? "bg-green-500 text-white"
                        : "bg-red-500 text-white"
                    }`}
                    onClick={() => toggleStatus(task._id, task.status)}
                  >
                    {task.status}
                  </button>
                </li>
              ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default TaskDashboard;
