const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/tasksDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Task Schema
const taskSchema = new mongoose.Schema({
    title: String,
    category: String, // daily, weekly, monthly
    dueDate: Date,
    status: { type: String, default: "Incomplete" }
});

const Task = mongoose.model("Task", taskSchema);

// Get all tasks
app.get("/tasks", async (req, res) => {
    const tasks = await Task.find();
    res.json(tasks);
});

// Add a new task
app.post("/tasks", async (req, res) => {
    const { title, category, dueDate } = req.body;
    const newTask = new Task({ title, category, dueDate });
    await newTask.save();
    res.json(newTask);
});

// Update task status
app.put("/tasks/:id", async (req, res) => {
    const { status } = req.body;
    await Task.findByIdAndUpdate(req.params.id, { status });
    res.json({ message: "Task updated!" });
});

// Delete a task
app.delete("/tasks/:id", async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: "Task deleted!" });
});

app.listen(5000, () => console.log("Server running on port 5000"));
